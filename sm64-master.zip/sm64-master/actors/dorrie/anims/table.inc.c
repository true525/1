// 0x0600F638
const struct Animation *const dorrie_seg6_anims_0600F638[] = {
    &dorrie_seg6_anim_0600E18C,
    &dorrie_seg6_anim_0600E9BC,
    &dorrie_seg6_anim_0600F620,
};

#include "anim_05006070.inc.c"
#include "anim_05006154.inc.c"

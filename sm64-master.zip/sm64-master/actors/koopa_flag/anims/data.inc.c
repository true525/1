#include "anim_06001010.inc.c"

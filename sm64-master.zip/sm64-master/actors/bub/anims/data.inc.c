#include "anim_0601233C.inc.c"

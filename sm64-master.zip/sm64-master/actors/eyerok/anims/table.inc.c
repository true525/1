// 0x050116E4
const struct Animation *const eyerok_seg5_anims_050116E4[] = {
    &eyerok_seg5_anim_0500D270,
    &eyerok_seg5_anim_0500DF50,
    &eyerok_seg5_anim_0500E1D8,
    &eyerok_seg5_anim_0500E99C,
    &eyerok_seg5_anim_0500F3D8,
    &eyerok_seg5_anim_0500FCCC,
    &eyerok_seg5_anim_050116CC,
    &eyerok_seg5_anim_0500F3F0,
    NULL,
};

// 0x0600E264
const struct Animation *const cyan_fish_seg6_anims_0600E264[] = {
    &cyan_fish_seg6_anim_0600E24C,
    NULL,
    NULL,
};

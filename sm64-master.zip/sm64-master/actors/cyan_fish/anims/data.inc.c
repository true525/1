#include "anim_0600E24C.inc.c"

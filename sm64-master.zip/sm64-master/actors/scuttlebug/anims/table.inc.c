// 0x06015064
const struct Animation *const scuttlebug_seg6_anims_06015064[] = {
    &scuttlebug_seg6_anim_0601504C,
};

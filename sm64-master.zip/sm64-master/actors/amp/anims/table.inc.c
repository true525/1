const struct Animation *const dAmpAnimsList[] = {
    &dAmpAnimation,
};

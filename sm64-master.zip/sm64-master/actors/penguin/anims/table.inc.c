// 0x05008B74
const struct Animation *const penguin_seg5_anims_05008B74[] = {
    &penguin_seg5_anim_05008B5C,
    &penguin_seg5_anim_050079E4,
    &penguin_seg5_anim_05007DCC,
    &penguin_seg5_anim_050087C0,
    &penguin_seg5_anim_05008B5C, // duplicate pointer?
};
